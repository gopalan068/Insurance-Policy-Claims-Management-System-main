import React from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';

// Layout & Protected Route
import ProtectedRoute from './components/ProtectedRoute';
import AdminLayout from './components/AdminLayout';

// Pages
import Login from './pages/Login';
import Dashboard from './pages/admin/Dashboard';
import Users from './pages/admin/Users';
import Customers from './pages/admin/Customers';
import Agents from './pages/admin/Agents';
import ClaimsOfficers from './pages/admin/ClaimsOfficers';
import Policies from './pages/admin/Policies';
import PolicyPurchases from './pages/admin/PolicyPurchases';
import Claims from './pages/admin/Claims';
import ClaimDetails from './pages/admin/ClaimDetails';
import Documents from './pages/admin/Documents';
import Reports from './pages/admin/Reports';
import AuditLogs from './pages/admin/AuditLogs';
import Profile from './pages/admin/Profile';

function App() {
  return (
    <Routes>
      {/* Public Login Route */}
      <Route path="/login" element={<Login />} />

      {/* Root redirect */}
      <Route path="/" element={<Navigate to="/admin/dashboard" replace />} />

      {/* Protected Admin Routes */}
      <Route
        path="/admin"
        element={
          <ProtectedRoute>
            <AdminLayout />
          </ProtectedRoute>
        }
      >
        <Route index element={<Navigate to="/admin/dashboard" replace />} />
        <Route path="dashboard" element={<Dashboard />} />
        <Route path="users" element={<Users />} />
        <Route path="customers" element={<Customers />} />
        <Route path="agents" element={<Agents />} />
        <Route path="claims-officers" element={<ClaimsOfficers />} />
        <Route path="policies" element={<Policies />} />
        <Route path="policy-purchases" element={<PolicyPurchases />} />
        <Route path="claims" element={<Claims />} />
        <Route path="claims/:id" element={<ClaimDetails />} />
        <Route path="documents" element={<Documents />} />
        <Route path="reports" element={<Reports />} />
        <Route path="audit-logs" element={<AuditLogs />} />
        <Route path="profile" element={<Profile />} />
      </Route>

      {/* Fallback */}
      <Route path="*" element={<Navigate to="/admin/dashboard" replace />} />
    </Routes>
  );
}

export default App;
