import os
from contextlib import asynccontextmanager
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles

from config import settings
from database import engine, Base
from seed import seed_database

# Routers
from routers.auth import router as auth_router
from routers.admin_dashboard import router as dashboard_router
from routers.admin_users import router as users_router
from routers.admin_customers import router as customers_router
from routers.admin_agents import router as agents_router
from routers.admin_officers import router as officers_router
from routers.admin_policies import router as policies_router
from routers.admin_purchases import router as purchases_router
from routers.admin_claims import router as claims_router
from routers.admin_documents import router as documents_router
from routers.admin_reports import router as reports_router
from routers.admin_audit import router as audit_router

@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup: ensure tables exist and seed demo data if database is fresh
    Base.metadata.create_all(bind=engine)
    seed_database()
    yield
    # Shutdown logic if any

app = FastAPI(
    title="Insurance Policy & Claims Management System - Admin API",
    description="Comprehensive Administrative backend for user management, policy operations, claim monitoring, document monitoring, and system analytics.",
    version="1.0.0",
    docs_url="/docs",
    redoc_url="/redoc",
    lifespan=lifespan
)

# CORS Configuration
origins = [
    settings.FRONTEND_URL,
    "http://localhost:5173",
    "http://127.0.0.1:5173",
    "http://localhost:3000",
]

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Ensure upload directory exists
os.makedirs(settings.UPLOAD_DIR, exist_ok=True)

# Register Routers
app.include_router(auth_router)
app.include_router(dashboard_router)
app.include_router(users_router)
app.include_router(customers_router)
app.include_router(agents_router)
app.include_router(officers_router)
app.include_router(policies_router)
app.include_router(purchases_router)
app.include_router(claims_router)
app.include_router(documents_router)
app.include_router(reports_router)
app.include_router(audit_router)

@app.get("/api/health", tags=["Health"])
def health_check():
    return {
        "status": "healthy",
        "service": "Insurance Admin Module API",
        "version": "1.0.0"
    }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="127.0.0.1", port=8000, reload=True)
